from src.tcp import Tcp

t = Tcp()